
//CLIMATE CHANGE  
//#climatechange

//String query = "donateclimatechange";
//String text1 = "350.org  Followers 255,564  Tweets 25,377  Total contributions $7.3 million  CEO salary N/A";
//String text2 = "Nature Conservancy  Followers 469, 943  Tweets 17,223  Total contributions $598 million  President/CEO salary $587,752";
//String text3 = "Rainforest Alliance  Followers 131,212  Tweets 21,434  Total contributions $12.5 million President salary $273,703";
//String text4 = "Total giving in to charitable organizations was $358.38 billion in 2014";


//HUNGER
//#hunger
//String query = "donatehunger";
//String text1 = "Action Against  Followers 10,482  Tweets 13,722  Total contributions $296 million Executive USA Director salary $216,904";
//String text2 = "Heifer International  Followers 247,650  Tweets 20,490  Total contributions  $111 million  CEO salary $313,008";
//String text3 = "Oxfam International  Followers 711, 288  Tweets 24,982  Total contributions  $14 million  President salary $437,699";
//String text4 = "51 percent of social media users hear about new social good initiatives on social media first";

//ANIMAL RIGHTS
//#animalrights
String query = "donateanimalrights";
String text1 = "Royal Society for Prevention of Cruelty Followers 204,928 Tweets 55,548 Total contributions $175.9 million CEO salary $198,632"; 
                        //Patrons include Queen Elizabeth II
String text2 = "PETA  Followers 603,284  Tweets 206,528  Total contributions  $40.5 million President salary $37,316";
String text3 = "World Wildlife Fund  Followers 653,644  Tweets 9,232  Total contributions $165.2 million President/CEO salary $637,686";
String text4 = "64 percent of US social media users donated $100 or more to charitable causes in 2014";


//BREAST CANCER
//#breastcancer
//String query = "donatebreastcancer";
//String text1 = "Susan G. Komen for the Cure  Followers 113,582  Tweets 10,999  Total contributions $198 million  President salary $480,784";
//String text2 = "Breast Cancer Now  Followers 27,151  Tweets 30,601  Total contributions $18.5 million CEO salary";
//String text3 = "Breast Cancer Care  Followers 128,358  Tweets 26,681  Total contributions $21.9 million  CEO salary";
//String text4 = "The Breast Cancer Society was part of a 2015 scam that conned donors out of $187 million from 2008 through 2012";



//REFUGEES
//#refugees
//String query = "donaterefugees";
//String text1 = "Save the Children  Followers 132,979 Tweets 19,100  Total contributions $452.7 million CEO salary $407,399";
//String text2 = "UN Commissioner for Refugees  Followers 1,860,232 Tweets 25,774  Total contributions $137.0 million  CEO salary $210,320";
//String text3 = "Just Giving Aylan Kurdi Fundraising  Twitter Followers 2975  Tweets 4,189  CEO salary $107,205";
//String text4 = "The dead boy on beach photo increased charity daily fundraising from $11,247 to over $1 million";



